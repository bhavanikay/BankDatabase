/**************************************************************
// NAME:        Bhavanika Yadav
//
// // HOMEWORK:    Project 1
// // CLASS:       ICS 212
//
// // INSTRUCTOR:  Ravi Narayan
//
// // DATE:        October 30, 2021
//
// // FILE:        user_interface.c
//
// // DESCRIPTION:
// // This file contains the user interface for Project 1, including main and get address function.
*************************************************************/
#include <stdio.h>
#include "string.h"
#include "record.h"
#include "database.h"
#define ESC 27
int debugmode = 0;
void getaddress(char [], int);

int main(int argc, char *argv[])

{
    struct record *start;
    char address[150], name[50], newAddress[150], temp[20];
    int true, redirect, acctNum, i;
    char add[3], view[3], view_all[3], edit[3], delete[3], quit[3], menuIn[3]; 

    start = NULL;    
    strcpy(add, "1\n");
    strcpy(view, "2\n");
    strcpy(view_all, "3\n");
    strcpy(edit, "4\n");
    strcpy(delete, "5\n");
    strcpy(quit, "0\n");

    true = 1;
    redirect = 1;

    if (argc == 2)
    {
        if (strcmp(argv[1], "debug") == 0 )
        {
            debugmode = 1;
        }
        else
        {
            true = 0;
            printf("Invalid Command, program running in debug mode.\n");
        }
    }
    else if (argc > 2)
    {
        true = 0;
        printf("Invalid Command, program running in debug mode.\n");
    } 
    readfile(&start, "database.txt");

    while (true == 1)
    {
        printf("Choose an option by entering the corresponding number:\n");
        printf("\n");
        printf("1: Add a new record\n");
        printf("2: View an existing record\n");
        printf("3: View all existing records\n");
        printf("4: Edit an existing record\n");
        printf("5: Delete an existing record\n");
        printf("0: Exit program\n");

        fgets(menuIn, 3, stdin);

        if (strcmp(menuIn, quit) == 0)
        {
            true = 0;
            printf("Thank you for using this program, exiting now");
        }
        else if (strcmp(menuIn, add) == 0)
        {
            redirect = 1;
            while (redirect == 1)
            {
                printf("Enter the new account number: ");
                if (scanf("%d", &acctNum) == 1)
                {
                    if (acctNum < 1)
                    {
                        printf("The account number cannot be negative\n");
                        fgets(temp, 19, stdin);
                    }
                    else
                    {
                        redirect = 0;
                    }
                }
                else
                {
                    printf("The account number must be an integer.\n");
                    fgets(temp, 19, stdin);
                }
            }
            fgets(temp, 19, stdin);
            printf("Enter name: ");
            fgets(name, 49, stdin);
            getaddress(address, 80);
            fgets(temp, 19, stdin);

            for (i = 0; name[i] != '\0'; i++)
            {
                if (name[i] == '\n')
                {
                    name[i] = ' ';
                }
            }

            if (addRecord(&start, acctNum, name, address) == 0)
            {
                printf("The new account has been added.\n");
            }
        }
        else if (strcmp(menuIn, view) == 0)
        {
            if (start == NULL)
            {
                printf("There are no existing records.\n");;
            }
            else
            {
                printf("Enter the account number of the account you want to view: ");
                scanf("%d", &acctNum);
                fgets(temp, 19, stdin);
                printRecord(start, acctNum);
            }
        }
        else if (strcmp(menuIn, view_all) == 0)
        {
            if (start == NULL)
            {
                printf("There are no existing records.\n");
            }
            else
            {
                printAllRecords(start);
            }
        }
        else if (strcmp(menuIn, edit) == 0)
        {
            if (start == NULL) 
            {
                printf("There are no existing records.\n");
            }
            else
            {
                printf("Enter the account number of the account you want to change: ");
                scanf("%d", &acctNum);
                fgets(temp, 19, stdin);
                getaddress(newAddress, 80);
                if ( modifyRecord(start, acctNum, newAddress) == 0 )
                {
                    printf("\nAddress has been modified.\n");
                }
                fgets(temp, 19, stdin);
            }
        }
        else if (strcmp(menuIn, delete) == 0)
        {
            if (start == NULL)
            {
                printf("There are no existing records.\n");
            }
            else
            {
                printf("Enter the account number: ");
                scanf("%d", &acctNum);
                fgets(temp, 19, stdin);
                deleteRecord(&start, acctNum);
            }
        }
    }
    writefile(start, "database.txt"); 
    cleanup(&start); 
    return 0;
}

/***************************************************************
// FUNCTION NAME:         getaddress
//
// // DESCRIPTION:           gets address for new record
//
// // PARAMETERS:            address (char[]): the inputted address
// //                        size (int): length of the address
//
// // RETURN VALUES:         void
//
// *****************************************************************/

void getaddress(char address[], int size)
{
    int i;
    char temp;

    i = 0;

    printf("Enter your address, then press escape & enter to exit:\n");
    while ((temp = getchar()) != 27)
    {
        address[i] = temp;
        i++;
    }

    address[i] = '\0';

    if (debugmode == 1)
    {   
        printf("+———————DEBUG MODE—————————+\n");
        printf("getaddress function was called with following parameters: \n");
        printf("char address[]: %s\n", address);
        printf("int size: %d\n", size);
        printf("-------------------------------------------\n");
    }    
}

