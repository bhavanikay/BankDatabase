/**************************************************************
// NAME:        Bhavanika Yadav
//
// // HOMEWORK:    Project 1
//
// // CLASS:       ICS 212
//
// // INSTRUCTOR:  Ravi Narayan
//
// // DATE:        October 30, 2021
//
// // FILE:        database.h
//
// // DESCRIPTION:
// // This file contains the headers for database.c 
//  ***************************************************************/

#include <stdio.h>

int addRecord (struct record **, int, char *,char *);
int printRecord (struct record *, int);
void printAllRecords(struct record *);
int modifyRecord (struct record *, int, char *);
int deleteRecord(struct record **, int);
int readfile(struct record **, char *);
int writefile(struct record *, char *);
void cleanup(struct record **);
