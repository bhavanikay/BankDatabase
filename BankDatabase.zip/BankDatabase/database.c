/**************************************************************
// NAME:        Bhavanika Yadav
//
// // HOMEWORK:    Project 1
//
// // CLASS:       ICS 212
//
// // INSTRUCTOR:  Ravi Narayan
//
// // DATE:        October 30, 2021
//
// // FILE:        database.c
//
// // DESCRIPTION:
// // This file contains the database functions for Project 1,
//  ***************************************************************/

#include <stdio.h>
#include <string.h>
#include "record.h"
#include <stdlib.h>
#include "database.h"

extern int debugmode;

/***********************************************
// FUNCTION NAME:    addRecord
//
// // DESCRIPTION:      Adds a new record to the database
//
// // PARAMETERS:       struct record **: starting record in list
// //                   int: account number
// //                   char[]: name of the account
// //                   char[]: address of the account
//
// // RETURN VALUES:    int 0 : Success
// //                      -1 : Fail
// ***********************************************/

int addRecord(struct record **start, int accountno,  char name[], char address[])
{
    int addrec;
    int execute;
    struct record *temp;
    struct record *current;
    struct record *prev;
    addrec = -1;

    if (debugmode == 1)
    {
        printf("\n+—————————DEBUG MODE————————+\n");
        printf("addRecord function has been called with following parameters:\n");
        printf("struct record **start: %p\n", (void *) &start);
        printf("int accountno: %d\n", accountno);
        printf("char name[]: %s\n", name);
        printf("char address[]: %s\n", address);
        printf("-----------------------------------------\n");
        printf("\n");
    }
    if ( *start == NULL )
    {
        temp = (struct record*)malloc(sizeof(struct record));
        (*temp).accountno = accountno;
        strcpy((*temp).name, name);
        strcpy((*temp).address, address);
        (*temp).next = NULL;
        *start = temp;
        current = *start;
        addrec = 0;
    }
    else if( accountno > (**start).accountno )
    {
        temp = (struct record*)malloc(sizeof(struct record));
        (*temp).accountno = accountno;
        strcpy((*temp).name, name);
        strcpy((*temp).address, address);
        (*temp).next = *start;
        *start = temp;
        current = *start;
        addrec = 0;
    }
    else
    {
        execute = 1;
        current = *start;
        prev = current;
        while ( execute == 1 )
        {
            if ( accountno  == (*current).accountno )
            {
                printf("accountno: %d\n", accountno);
                printf("current: %d\n", (*current).accountno);
                printf("Cannot use duplicate numbers\n");
                execute = 0;
            }
            else if ( accountno  > (*current).accountno )
            {
                temp = (struct record*)malloc(sizeof(struct record));
                (*temp).accountno = accountno;
                strcpy((*temp).name, name);
                strcpy((*temp).address, address);
                (*temp).next = current;
                (*prev).next = temp;
                addrec = 0;
                execute = 0;
            }       
            else if ( (*current).next == NULL )
            {
                temp = (struct record*)malloc(sizeof(struct record));
                (*temp).accountno = accountno;
                strcpy((*temp).name, name);
                strcpy((*temp).address, address);    
                (*current).next = temp;
                (*temp).next = NULL;
                addrec = 0;
                execute = 0;   
            }
            else
            {
                prev = current;
                current = (*current).next;
            }
        }
    }
    return addrec;
}

/***********************************************
// FUNCTION NAME:    printRecord
//
// // DESCRIPTION:      Prints a record in the database
//
// // PARAMETERS:       struct record *: starting record in list
// //                   int: account number
// // RETURN VALUES:    int 0 : Successfully Printed
// //                      -1 : Failed
// ***********************************************/
int printRecord( struct record *start, int accountno )
{
    int print;
    int execute;
    struct record *current;
    struct record *current_next;
    
    execute = 1;
    print = -1;

    if ( debugmode == 1)
    {
        printf("\n+————————DEBUG MODE—————————+\n");
        printf("printRecord function has been called with following parameters:\n");
        printf("struct record *start is: %p\n", (void *) start);
        printf("int accountno: %d\n", accountno);
        printf("------------------------------------------------\n");
        printf("\n");
    }

    current = start;

    while ( current != NULL && execute == 1 )
    {
        current_next = (*current).next;

        if ((*current).accountno == accountno )
        {
            printf("\nAccount number: %d\n", (*current).accountno);
            printf("Name: %s\n", (*current).name);
            printf("Address:\n");
            printf("%s\n", (*current).address);
            printf("\n");
            execute = 0;
            print = 0;
        }
        else if ( (*current).next == NULL && (*current).accountno != accountno )
        {
            execute = 0;
        }
        else
        {
            current = current_next;
            current_next = (*current).next;
        }
    }
    if ( print == -1 )
    {
        printf("\nThe record with the account number %d does not exist!\n", accountno);

        printf("\n");
    }
    return print;
}

/***********************************************
// FUNCTION NAME:    printAllRecord
//
// // DESCRIPTION:      Prints all records in the database
//
// // PARAMETERS:       struct record *: starting record in list
//
// // RETURN VALUES:    void
// ***********************************************/

void printAllRecords(struct record *start)
{
    struct record *current;
    struct record *current_next;
    int execute;

    execute = 1;

    if ( debugmode == 1)
    {
        printf("\n+—————————DEBUG MODE————————+\n");
        printf("printAllRecord function has been called with following parameters:\n");
        printf("struct record *start is: %p\n", (void *) start);
        printf("----------------------------------------------\n");
        printf("\n");
    }  

    current = start;

    while ( current != NULL && execute == 1 )
    {
        current_next = (*current).next;

        if ( current_next == NULL )
        {
            printf("\nAccount number: %d\n", (*current).accountno);
            printf("Name: %s\n", (*current).name);
            printf("Address:\n");
            printf("%s\n", (*current).address);
            printf("\n");
            execute = 0;
        }
        else
        {
            printf("\nAccount number: %d\n", (*current).accountno);
            printf("Name: %s\n", (*current).name);
            printf("Address:\n");
            printf("%s\n", (*current).address);
            printf("\n");
            current = current_next;
            current_next = (*current).next;
        }
    }
}

/*************************************************
// FUNCTION NAME:    modifyRecord
//
// // DESCRIPTION:      Modifies address of a record in the database
//
// // PARAMETERS:       struct record *: starting record in list
// //                   int: account number
// //                   char[]: address of the account
//
// // RETURN VALUES:    int 0 : Success
//
// //                      -1 : Failed
// // ***********************************************/

int modifyRecord( struct record *start, int accountno, char address[] )
{
    int modified;
    struct record *current;
    struct record *current_next;
    int execute;    
    modified = -1;
    execute = 1;

    if ( debugmode == 1 )
    {
        printf("\n+—————————DEBUG MODE————————+\n");
        printf("modifyRecord function has been called with the parameters:\n");
        printf("struct record *start is: %p\n", (void *) start);
        printf("int accountno: %d\n", accountno);
        printf("char address[]: %s\n", address);
        printf("-------------------------------------------------\n");
        printf("\n");
    }

    current = start;
    while ( current != NULL && execute == 1 )
    {   
        current_next = (*current).next;
        if ((*current).accountno == accountno)
        {
            strcpy( (*current).address, address );            
            modified = 0;
            execute = 0;
        }
        else if ( (*current).next == NULL && (*current).accountno != accountno)
        {
            execute = 0;
        }
        else
        {   
            current = current_next;
            current_next = (*current).next;
        }
    } 
    if ( modified == -1 )
    {
            printf("\nThe record with the account number %d does not exist!\n", accountno);
    }
    return modified;
}

/***********************************************
// FUNCTION NAME:    deleteRecord
//
// // DESCRIPTION:      Deletes a record in the database
//
// // PARAMETERS:       struct record **: starting record in list
// //                   int: account number
//
// // RETURN VALUES:    int 0 : Deleted
// //                      -1 : Failed
// ***********************************************/

int deleteRecord( struct record **start, int accountno)
{
    int deleted;
    int execute;
    struct record *current;
    struct record *temp;
    struct record *prev;
    deleted = -1;
    execute = 1;

    if ( debugmode == 1 )              
    {
        printf("\n+—————————DEBUG MODE————————+\n");
        printf("deleteRecord function has been called with following parameters:\n");
        printf("struct record *start is: %p\n", (void *) start);
        printf("int accountno: %d\n", accountno);
        printf("-------------------------------------------------------\n");
        printf("\n");
    }

    current = *start;
    prev = current;

    while ( current != NULL && execute == 1 )
    {   
        if ( (*current).accountno == accountno )
        {
            if ( current == *start && (*current).next == NULL )
            {
                temp = current;
                *start = NULL;
                current = NULL;
                prev = NULL;
                free(temp);
                deleted = 0;
                execute = 0;
            }
            else if ( current == *start && (*current).next != NULL )
            {
                temp = current;
                *start = (*current).next;
                current = *start;
                prev = current;
                free(temp);
                deleted = 0;
                execute = 0;
            }
            else
            {
                temp = current;
                current = (*current).next;
                (*prev).next = current;
                free(temp);
                deleted = 0;
                execute = 0;
            }
        }
        else
        {   
            prev = current;
            current = (*current).next;
        }
    }
    if ( deleted == -1 )
    {
        printf("\nThe record does not exist.\n");
        printf("\n");
    }
    else
    {
        printf("\nThe record has been deleted.\n");
        printf("\n");
    }
    return deleted;
}

/******************************************************************
// FUNCTION NAME:         cleanup
//
// // DESCRIPTION:           deletes all records in database
//
// // PARAMETERS:            start (record *): the start record
//
// // RETURN:                void
// *****************************************************************/

void cleanup( struct record **start)
{
    struct record *current;
    struct record *current_next;
    struct record *temp;
    int execute;
    execute = 1;

    if ( debugmode == 1)
    {
        printf("\n+—————————DEBUG MODE————————+\n");
        printf("cleanup function has been called with following parameters:\n");
        printf("struct record *start is: %p\n", (void *) start);
        printf("-------------------------------------------------------\n");
        printf("\n");
    }

    current = *start;

    while ( current != NULL && execute == 1 )
    {
        current_next = (*current).next;

        if ( current_next == NULL )
        {
            temp = current;
            *start = NULL;
            current = *start;
            current_next = current;
            free(temp);
            execute = 0;
        }
        else
        {
            temp = current;
            current = current_next;
            current_next = (*current).next;
            free(temp);
        }
    }
}

/******************************************************************
// FUNCTION NAME:         readfile
//
// // DESCRIPTION:           reads records from data file
//
// // PARAMETERS:            struct record **: start of the list
// //                        char[]: name of file that is being read
//
// // RETURN:            int 0: success
// //                       -1: fail
//
// ********************************************************************/

int readfile( struct record **start, char filename[] )
{
    FILE *input;   
    int accountno;
    char name[25], address[80], temp[2];
    int true;

    true = 0;

    if ( debugmode == 1)
    {
        printf("\n+—————————DEBUG MODE————————+\n");
        printf("readfile function has been called with following parameters:\n");
        printf("struct record **start is: %p\n", (void *) start);
        printf("char filename[]: %s\n", filename);
        printf("-------------------------------------------------------\n");
        printf("\n");
    }

    input = fopen("database.txt", "r");

    if (input == NULL )
    { 
        true = -1;
    }
    else
    {
        while ( fgetc(input) != EOF )
        {
            fscanf(input, "%i[^\n]", &accountno);
            fscanf(input, "%c", temp);
            fscanf(input, "%[^\n]", name);
            fscanf(input, "%c", temp);
            fscanf(input, "%[^$]", address);
            fscanf(input, "%c", temp);
            addRecord(start, accountno, name, address);
        }  
    fclose(input);
    }
    return true;
}

/*****************************************************************
// FUNCTION NAME:       writefile
//
// // DESCRIPTION:         writes any modifications 
//
// // PARAMETERS:          start (record *): the start of the list
// //                      filename (char []): the file that is written on
//
// // RETURN:              0: success
// //                     -1: fail
// *****************************************************************/

int writefile( struct record *start, char filename[] )
{
    FILE *output;
    struct record *current;
    struct record *current_next;
    int execute;
    int true;

    true = 0;
    execute = 1;

    if ( debugmode == 1)
    {
        printf("\n+—————————DEBUG MODE————————+\n");
        printf("writefile function has been called with following parameters:\n");
        printf("struct record *start is: %p\n", (void *) start);
        printf("char filename[]: %s\n", filename);
        printf("-------------------------------------------------------\n");
        printf("\n");
    }   
    output = fopen("database.txt", "w");
    current = start;

    if ( output == NULL )
    {
        true = -1;
    }
    else
    {   
        while ( current != NULL && execute == 1 )

        {   
            current_next = (*current).next;

            if ( current_next == NULL )
            {
                fprintf(output, "0%i\n", (*current).accountno);
                fprintf(output, "%s\n", (*current).name);
                fprintf(output, "%s$", (*current).address);   
                fclose(output);
                execute = 0;
            }
            else
            {   
                fprintf(output, "0%i\n", (*current).accountno);
                fprintf(output, "%s\n", (*current).name);
                fprintf(output, "%s$", (*current).address);
                current = current_next;
                current_next = (*current).next;
            }
        }
    }     
    return true;
}




